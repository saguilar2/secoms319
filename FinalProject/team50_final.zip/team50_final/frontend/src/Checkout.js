export function Checkout() {
    return ( <div>Checkout</div> );
}